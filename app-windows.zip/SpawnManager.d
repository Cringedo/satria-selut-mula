bin/SpawnManager.o: src/SpawnManager.cpp include/self/SpawnManager.hpp \
 include/self/Entity.hpp include/self/GameObject.hpp include/raylib.h \
 include/raymath.h include/self/json.hpp
include/self/SpawnManager.hpp:
include/self/Entity.hpp:
include/self/GameObject.hpp:
include/raylib.h:
include/raymath.h:
include/self/json.hpp:
