bin/entities/Player.o: src/entities/Player.cpp \
 include/self/GameObject.hpp include/raylib.h include/raymath.h \
 include/self/Constant.h include/self/Grid.hpp include/self/Entity.hpp
include/self/GameObject.hpp:
include/raylib.h:
include/raymath.h:
include/self/Constant.h:
include/self/Grid.hpp:
include/self/Entity.hpp:
