bin/entities/Entity.o: src/entities/Entity.cpp include/raylib.h \
 include/self/Constant.h include/self/Entity.hpp \
 include/self/GameObject.hpp include/raymath.h
include/raylib.h:
include/self/Constant.h:
include/self/Entity.hpp:
include/self/GameObject.hpp:
include/raymath.h:
