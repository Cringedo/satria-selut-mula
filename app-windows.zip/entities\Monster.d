bin/entities/Monster.o: src/entities/Monster.cpp include/self/Entity.hpp \
 include/self/GameObject.hpp include/raylib.h include/raymath.h \
 include/self/Constant.h
include/self/Entity.hpp:
include/self/GameObject.hpp:
include/raylib.h:
include/raymath.h:
include/self/Constant.h:
