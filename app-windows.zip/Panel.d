bin/Panel.o: src/Panel.cpp include/self/Panel.hpp include/raylib.h
include/self/Panel.hpp:
include/raylib.h:
