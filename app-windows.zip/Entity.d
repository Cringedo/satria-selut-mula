bin/Entity.o: src/Entity.cpp include/raylib.h include/self/Constant.h \
 include/self/Entity.hpp include/self/GameObject.hpp include/raymath.h
include/raylib.h:
include/self/Constant.h:
include/self/Entity.hpp:
include/self/GameObject.hpp:
include/raymath.h:
