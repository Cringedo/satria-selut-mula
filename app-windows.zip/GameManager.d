bin/GameManager.o: src/GameManager.cpp include/raylib.h \
 include/self/GameManager.hpp include/self/Entity.hpp \
 include/self/GameObject.hpp include/raymath.h include/self/Grid.hpp \
 include/self/json.hpp include/self/Constant.h \
 include/self/FastNoiseLite.h
include/raylib.h:
include/self/GameManager.hpp:
include/self/Entity.hpp:
include/self/GameObject.hpp:
include/raymath.h:
include/self/Grid.hpp:
include/self/json.hpp:
include/self/Constant.h:
include/self/FastNoiseLite.h:
