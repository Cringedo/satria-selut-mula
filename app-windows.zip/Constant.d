bin/Constant.o: src/Constant.cpp include/self/Constant.h include/raylib.h
include/self/Constant.h:
include/raylib.h:
