bin/strategies/AttackStrategy.o: src/strategies/AttackStrategy.cpp \
 include/self/AttackStrategy.hpp include/self/Entity.hpp \
 include/self/GameObject.hpp include/raylib.h include/raymath.h
include/self/AttackStrategy.hpp:
include/self/Entity.hpp:
include/self/GameObject.hpp:
include/raylib.h:
include/raymath.h:
